from stegano import lsb
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes
import base64
import os
from hashlib import sha256

def encrypt_data(data, key):
    cipher = AES.new(key, AES.MODE_CBC)
    encrypted = cipher.encrypt(pad(data, AES.block_size))
    return cipher.iv + encrypted

def decrypt_data(encrypted_data, key):
    iv = encrypted_data[:AES.block_size]
    encrypted = encrypted_data[AES.block_size:]
    cipher = AES.new(key, AES.MODE_CBC, iv)
    return unpad(cipher.decrypt(encrypted), AES.block_size)

def simulate_apk_hiding(apk_path, png_path, output_path, key):
    with open(apk_path, 'rb') as f:
        apk_data = f.read()

    encrypted_apk = encrypt_data(apk_data, key)
    hidden_string = base64.b64encode(encrypted_apk).decode('utf-8')
    
    secret = lsb.hide(png_path, hidden_string)
    secret.save(output_path)
    print(f"[+] Hidden APK saved to {output_path}")

def simulate_apk_extraction(png_path, output_apk_path, key):
    hidden_string = lsb.reveal(png_path)
    encrypted_apk = base64.b64decode(hidden_string.encode('utf-8'))
    apk_data = decrypt_data(encrypted_apk, key)

    with open(output_apk_path, 'wb') as f:
        f.write(apk_data)
    print(f"[+] Extracted APK saved to {output_apk_path}")

def main():
    apk_path = input("Enter APK file path: ")
    png_path = input("Enter PNG file path: ")
    output_png_path = input("Enter output PNG file path: ")
    output_apk_path = input("Enter output APK file path: ")
    password = input("Enter password for encryption/decryption: ")

    key = sha256(password.encode()).digest()

    if not os.path.exists(apk_path) or not os.path.exists(png_path):
        print("[!] File paths are invalid.")
        return

    simulate_apk_hiding(apk_path, png_path, output_png_path, key)
    simulate_apk_extraction(output_png_path, output_apk_path, key)

if __name__ == "__main__":
    main()
